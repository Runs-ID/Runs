<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<p><strong>Código de autentificación:</strong> <?php echo e($form['token_generate']); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\Runsv2\Runs\resources\views/recover_password.blade.php ENDPATH**/ ?>