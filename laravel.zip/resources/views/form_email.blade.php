<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<h1>Runs contacto - nuevo mensaje</h1>
	<p><strong>Nombre:</strong>{{$form['name_contact']}}</p>
	<p><strong>Email:</strong>{{$form['email_contact']}}</p>
	<p><strong>Mensaje:</strong>{{$form['message_contact']}}</p>
</body>
</html>